clear
javac -cp .:samplePlayer.jar BattleshipMain.java