c.sh 
- compile all

go.sh 
- run game with 2 parameters (from random | greedy | prob | custom) and text file (param1_v_param2.txt) created

do. sh 
- same as go.sh but without rendering the grid & executed 10 times;
- amendments made to BattleShipMain.java to check whether P1/P2 were instanceof RandomGuessPlayer or GreedyGuessPlayer
- asterisk used to indicate which player won
