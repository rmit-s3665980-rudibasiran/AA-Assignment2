c.sh - compile all
go.sh - run game with 2 parameters (from random | greedy | prob | custom) and text file (param1_v_param2.txt) created
